#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片编辑器 - 智能去水印增强版
功能：多次迭代修复、自适应半径、残留检测
"""

import sys
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from PIL import Image, ImageDraw, ImageTk, ImageFilter
import numpy as np
import cv2


class ImagesEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("图片编辑器 - 智能去水印增强版")
        self.root.geometry("1400x900")
        self.root.configure(bg='#2b2b2b')

        # 初始化变量
        self.current_image = None
        self.display_image = None
        self.original_image = None
        self.file_path = None
        self.zoom_factor = 1.0

        # 绘画变量
        self.drawing = False
        self.draw_mode = "铅笔"
        self.current_color = (255, 0, 0)
        self.brush_size = 5
        self.last_x = None
        self.last_y = None

        # 去水印变量
        self.watermark_selecting = False
        self.watermark_start = None
        self.watermark_end = None
        self.watermark_rect = None
        self.watermark_mode = False
        self.detection_mask = None
        self.mask_coords = None

        # 增强参数
        self.sensitivity = tk.IntVar(value=30)  # 提高默认敏感度
        self.feather_radius = tk.IntVar(value=3)
        self.iterations = tk.IntVar(value=2)  # 迭代次数
        self.repair_radius = tk.IntVar(value=5)  # 修复半径

        # RGB变量
        self.r_var = tk.StringVar(value="255")
        self.g_var = tk.StringVar(value="0")
        self.b_var = tk.StringVar(value="0")

        # 历史记录
        self.history = []
        self.max_history = 10

        self.setup_ui()

    def setup_ui(self):
        # 主框架
        main_frame = tk.Frame(self.root, bg='#2b2b2b')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 左侧工具栏
        toolbar_container = tk.Frame(main_frame, bg='#2b2b2b', width=260)
        toolbar_container.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))
        toolbar_container.pack_propagate(False)

        # 创建Canvas和滚动条
        toolbar_canvas = tk.Canvas(toolbar_container, bg='#3c3f41', width=240, highlightthickness=0)
        scrollbar = tk.Scrollbar(toolbar_container, orient="vertical", command=toolbar_canvas.yview)

        toolbar_canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        toolbar_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 工具栏内容框架
        toolbar = tk.Frame(toolbar_canvas, bg='#3c3f41', width=240)
        toolbar_canvas.create_window((0, 0), window=toolbar, anchor=tk.NW, width=240)

        def on_frame_configure(event):
            toolbar_canvas.configure(scrollregion=toolbar_canvas.bbox("all"))

        toolbar.bind("<Configure>", on_frame_configure)

        # 文件操作
        file_frame = tk.LabelFrame(toolbar, text=" 文件 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        file_frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Button(file_frame, text="打开图片", command=self.open_image, bg='#4b4b4b', fg='white', font=('微软雅黑', 9),
                  height=1).pack(fill=tk.X, padx=3, pady=2)
        tk.Button(file_frame, text="保存图片", command=self.save_image, bg='#4b4b4b', fg='white', font=('微软雅黑', 9),
                  height=1).pack(fill=tk.X, padx=3, pady=2)
        tk.Button(file_frame, text="撤销 (Ctrl+Z)", command=self.undo, bg='#4b4b4b', fg='white', font=('微软雅黑', 9),
                  height=1).pack(fill=tk.X, padx=3, pady=2)

        # 绘画工具
        draw_frame = tk.LabelFrame(toolbar, text=" 绘画工具 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        draw_frame.pack(fill=tk.X, padx=5, pady=5)

        self.pencil_btn = tk.Button(draw_frame, text="铅笔", command=lambda: self.set_draw_mode("铅笔"), bg='#5b5b5b',
                                    fg='white', font=('微软雅黑', 9), height=1)
        self.pencil_btn.pack(fill=tk.X, padx=3, pady=2)

        self.eraser_btn = tk.Button(draw_frame, text="橡皮擦", command=lambda: self.set_draw_mode("橡皮"), bg='#4b4b4b',
                                    fg='white', font=('微软雅黑', 9), height=1)
        self.eraser_btn.pack(fill=tk.X, padx=3, pady=2)

        self.picker_btn = tk.Button(draw_frame, text="取色器", command=lambda: self.set_draw_mode("取色器"),
                                    bg='#4b4b4b', fg='white', font=('微软雅黑', 9), height=1)
        self.picker_btn.pack(fill=tk.X, padx=3, pady=2)

        # 颜色选择
        color_frame = tk.LabelFrame(toolbar, text=" 颜色设置 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        color_frame.pack(fill=tk.X, padx=5, pady=5)

        color_preview_frame = tk.Frame(color_frame, bg='#3c3f41')
        color_preview_frame.pack(pady=5)

        self.color_preview = tk.Canvas(color_preview_frame, width=60, height=30, bg='#ff0000', highlightthickness=2,
                                       highlightbackground='white')
        self.color_preview.pack()

        tk.Button(color_frame, text="选择颜色", command=self.choose_color, bg='#4b4b4b', fg='white',
                  font=('微软雅黑', 9), height=1).pack(fill=tk.X, padx=3, pady=2)

        # RGB输入
        rgb_frame = tk.Frame(color_frame, bg='#3c3f41')
        rgb_frame.pack(fill=tk.X, padx=3, pady=3)

        rgb_labels = [("红:", self.r_var), ("绿:", self.g_var), ("蓝:", self.b_var)]
        for i, (label, var) in enumerate(rgb_labels):
            tk.Label(rgb_frame, text=label, bg='#3c3f41', fg='white', font=('微软雅黑', 9), width=3).grid(row=i,
                                                                                                          column=0,
                                                                                                          sticky='e',
                                                                                                          pady=1)
            tk.Entry(rgb_frame, textvariable=var, width=6, bg='#4b4b4b', fg='white', insertbackground='white',
                     font=('微软雅黑', 9), justify='center').grid(row=i, column=1, pady=1)

        tk.Button(rgb_frame, text="应用RGB", command=self.apply_rgb, bg='#4b4b4b', fg='white', font=('微软雅黑', 9),
                  height=1).grid(row=3, column=0, columnspan=2, pady=5)

        # 画笔大小
        size_frame = tk.LabelFrame(toolbar, text=" 画笔大小 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        size_frame.pack(fill=tk.X, padx=5, pady=5)

        self.size_scale = tk.Scale(size_frame, from_=1, to=50, orient=tk.HORIZONTAL, bg='#3c3f41', fg='white',
                                   highlightthickness=0, font=('微软雅黑', 9))
        self.size_scale.set(5)
        self.size_scale.pack(fill=tk.X, padx=3)

        # 智能去水印 - 增强版
        wm_frame = tk.LabelFrame(toolbar, text=" 智能去水印(增强版) ", bg='#3c3f41', fg='#ff6b6b',
                                 font=('微软雅黑', 10, 'bold'))
        wm_frame.pack(fill=tk.X, padx=5, pady=5)

        # 参数设置
        tk.Label(wm_frame, text="检测敏感度:", bg='#3c3f41', fg='white', font=('微软雅黑', 9)).pack(anchor='w', padx=3,
                                                                                                    pady=(5, 0))
        tk.Scale(wm_frame, from_=10, to=100, orient=tk.HORIZONTAL, variable=self.sensitivity, bg='#3c3f41', fg='white',
                 highlightthickness=0, font=('微软雅黑', 9)).pack(fill=tk.X, padx=3)

        tk.Label(wm_frame, text="修复半径(越大越干净):", bg='#3c3f41', fg='white', font=('微软雅黑', 9)).pack(
            anchor='w', padx=3)
        tk.Scale(wm_frame, from_=3, to=15, orient=tk.HORIZONTAL, variable=self.repair_radius, bg='#3c3f41', fg='white',
                 highlightthickness=0, font=('微软雅黑', 9)).pack(fill=tk.X, padx=3)

        tk.Label(wm_frame, text="迭代次数(多次更干净):", bg='#3c3f41', fg='white', font=('微软雅黑', 9)).pack(
            anchor='w', padx=3)
        tk.Scale(wm_frame, from_=1, to=5, orient=tk.HORIZONTAL, variable=self.iterations, bg='#3c3f41', fg='white',
                 highlightthickness=0, font=('微软雅黑', 9)).pack(fill=tk.X, padx=3)

        tk.Label(wm_frame, text="边缘羽化:", bg='#3c3f41', fg='white', font=('微软雅黑', 9)).pack(anchor='w', padx=3)
        tk.Scale(wm_frame, from_=0, to=10, orient=tk.HORIZONTAL, variable=self.feather_radius, bg='#3c3f41', fg='white',
                 highlightthickness=0, font=('微软雅黑', 9)).pack(fill=tk.X, padx=3)

        # 去水印按钮
        self.wm_select_btn = tk.Button(wm_frame, text="1. 框选水印大致区域", command=self.start_watermark_selection,
                                       bg='#4b4b4b', fg='white', font=('微软雅黑', 9, 'bold'), height=2)
        self.wm_select_btn.pack(fill=tk.X, padx=3, pady=3)

        self.wm_detect_btn = tk.Button(wm_frame, text="2. 智能分析水印边界", command=self.smart_detect_watermark,
                                       bg='#4b4b4b', fg='#4ecdc4', font=('微软雅黑', 9, 'bold'), height=2)
        self.wm_detect_btn.pack(fill=tk.X, padx=3, pady=3)

        self.wm_preview_btn = tk.Button(wm_frame, text="预览检测效果", command=self.preview_detection, bg='#4b4b4b',
                                        fg='#ffeb3b', font=('微软雅黑', 9), height=1)
        self.wm_preview_btn.pack(fill=tk.X, padx=3, pady=2)

        self.wm_remove_btn = tk.Button(wm_frame, text="3. 深度去除水印", command=self.remove_watermark_deep,
                                       bg='#ff6b6b', fg='white', font=('微软雅黑', 10, 'bold'), height=2,
                                       relief=tk.RAISED, bd=3)
        self.wm_remove_btn.pack(fill=tk.X, padx=3, pady=3)

        self.wm_residue_btn = tk.Button(wm_frame, text="检测残留并补充修复", command=self.check_and_fix_residue,
                                        bg='#4b4b4b', fg='#ffa500', font=('微软雅黑', 9, 'bold'), height=2)
        self.wm_residue_btn.pack(fill=tk.X, padx=3, pady=3)

        self.wm_clear_btn = tk.Button(wm_frame, text="清除/取消", command=self.clear_watermark_selection, bg='#4b4b4b',
                                      fg='white', font=('微软雅黑', 9), height=1)
        self.wm_clear_btn.pack(fill=tk.X, padx=3, pady=3)

        # 提示标签
        tip_label = tk.Label(wm_frame, text="提示: 如去不干净，\n可提高敏感度或增加迭代次数", bg='#3c3f41', fg='#aaaaaa',
                             font=('微软雅黑', 8), wraplength=220, justify=tk.CENTER)
        tip_label.pack(pady=5)

        # 分辨率
        res_frame = tk.LabelFrame(toolbar, text=" 分辨率调整 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        res_frame.pack(fill=tk.X, padx=5, pady=5)

        self.res_var = tk.StringVar(value="原始尺寸")
        resolutions = ["原始尺寸", "16x16", "32x32", "48x48", "64x64", "128x128", "256x256", "512x512", "1024x1024"]
        res_menu = ttk.Combobox(res_frame, textvariable=self.res_var, values=resolutions, state="readonly",
                                font=('微软雅黑', 9))
        res_menu.pack(fill=tk.X, padx=3, pady=3)

        tk.Button(res_frame, text="应用分辨率", command=self.apply_resolution, bg='#4b4b4b', fg='white',
                  font=('微软雅黑', 9), height=1).pack(fill=tk.X, padx=3, pady=3)

        # 缩放控制
        zoom_frame = tk.LabelFrame(toolbar, text=" 视图缩放 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        zoom_frame.pack(fill=tk.X, padx=5, pady=5)

        tk.Button(zoom_frame, text="放大 (+)", command=lambda: self.zoom(1.2), bg='#4b4b4b', fg='white',
                  font=('微软雅黑', 9), height=1).pack(fill=tk.X, padx=3, pady=2)
        tk.Button(zoom_frame, text="缩小 (-)", command=lambda: self.zoom(0.8), bg='#4b4b4b', fg='white',
                  font=('微软雅黑', 9), height=1).pack(fill=tk.X, padx=3, pady=2)
        tk.Button(zoom_frame, text="适应窗口", command=self.fit_to_window, bg='#4b4b4b', fg='white',
                  font=('微软雅黑', 9), height=1).pack(fill=tk.X, padx=3, pady=2)

        # 信息面板
        info_frame = tk.LabelFrame(toolbar, text=" 图片信息 ", bg='#3c3f41', fg='white', font=('微软雅黑', 10, 'bold'))
        info_frame.pack(fill=tk.X, padx=5, pady=5, side=tk.BOTTOM)

        self.info_label = tk.Label(info_frame, text="未加载图片", bg='#3c3f41', fg='white', wraplength=220,
                                   justify=tk.LEFT, font=('微软雅黑', 9))
        self.info_label.pack(padx=5, pady=5)

        # 右侧画布区域
        canvas_frame = tk.Frame(main_frame, bg='#2b2b2b')
        canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 滚动条
        h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL)
        h_scroll.pack(side=tk.BOTTOM, fill=tk.X)

        v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL)
        v_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # 画布
        self.canvas = tk.Canvas(canvas_frame, bg='#1e1e1e', highlightthickness=0,
                                xscrollcommand=h_scroll.set, yscrollcommand=v_scroll.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        h_scroll.config(command=self.canvas.xview)
        v_scroll.config(command=self.canvas.yview)

        # 绑定事件
        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<Motion>", self.on_mouse_hover)
        self.root.bind("<Control-z>", lambda e: self.undo())

        # 状态栏
        self.status_bar = tk.Label(self.root, text="就绪 - 增强版去水印，支持多次迭代修复", bd=1, relief=tk.SUNKEN,
                                   anchor=tk.W, bg='#3c3f41', fg='white', font=('微软雅黑', 9))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def save_state(self):
        if self.current_image:
            self.history.append(self.current_image.copy())
            if len(self.history) > self.max_history:
                self.history.pop(0)

    def undo(self):
        if self.history and self.current_image:
            self.current_image = self.history.pop()
            self.update_display()
            self.status_bar.config(text="已撤销")
        else:
            self.status_bar.config(text="没有可撤销的操作")

    def set_draw_mode(self, mode):
        self.draw_mode = mode
        self.watermark_mode = False
        self.watermark_selecting = False

        self.pencil_btn.config(bg='#4b4b4b')
        self.eraser_btn.config(bg='#4b4b4b')
        self.picker_btn.config(bg='#4b4b4b')
        self.wm_select_btn.config(bg='#4b4b4b', fg='white')

        if mode == "铅笔":
            self.pencil_btn.config(bg='#5b5b5b')
            self.status_bar.config(text="铅笔模式")
        elif mode == "橡皮":
            self.eraser_btn.config(bg='#5b5b5b')
            self.status_bar.config(text="橡皮模式")
        elif mode == "取色器":
            self.picker_btn.config(bg='#5b5b5b')
            self.status_bar.config(text="取色器模式")

    def choose_color(self):
        color = colorchooser.askcolor(title="选择颜色", color=self.rgb_to_hex(self.current_color))
        if color[1]:
            self.current_color = tuple(int(x) for x in color[0])
            self.update_color_preview()
            self.update_rgb_entries()

    def rgb_to_hex(self, rgb):
        return '#{:02x}{:02x}{:02x}'.format(rgb[0], rgb[1], rgb[2])

    def update_color_preview(self):
        hex_color = self.rgb_to_hex(self.current_color)
        self.color_preview.config(bg=hex_color)

    def update_rgb_entries(self):
        self.r_var.set(str(self.current_color[0]))
        self.g_var.set(str(self.current_color[1]))
        self.b_var.set(str(self.current_color[2]))

    def apply_rgb(self):
        try:
            r = max(0, min(255, int(self.r_var.get())))
            g = max(0, min(255, int(self.g_var.get())))
            b = max(0, min(255, int(self.b_var.get())))
            self.current_color = (r, g, b)
            self.update_color_preview()
            self.status_bar.config(text=f"颜色: RGB({r},{g},{b})")
        except ValueError:
            messagebox.showerror("错误", "RGB数值无效")

    def open_image(self):
        file_path = filedialog.askopenfilename(
            title="选择图片",
            filetypes=[("图片文件", "*.png *.jpg *.jpeg *.gif *.bmp *.tiff"), ("所有文件", "*.*")]
        )
        if file_path:
            self.save_state()
            self.file_path = file_path
            self.original_image = Image.open(file_path).convert("RGBA")
            self.current_image = self.original_image.copy()
            self.zoom_factor = 1.0
            self.clear_watermark_selection()
            self.update_display()
            self.update_info()
            self.status_bar.config(text=f"已打开: {os.path.basename(file_path)}")

    def save_image(self):
        if self.current_image is None:
            messagebox.showwarning("警告", "没有可保存的图片")
            return

        file_path = filedialog.asksaveasfilename(
            title="保存图片",
            defaultextension=".png",
            filetypes=[("PNG图片", "*.png"), ("JPEG图片", "*.jpg"), ("所有文件", "*.*")]
        )
        if file_path:
            try:
                save_img = self.current_image.convert("RGB") if file_path.endswith(
                    ('.jpg', '.jpeg')) else self.current_image
                save_img.save(file_path)
                self.status_bar.config(text=f"已保存: {os.path.basename(file_path)}")
            except Exception as e:
                messagebox.showerror("错误", f"保存失败: {str(e)}")

    def reset_image(self):
        if self.original_image:
            self.save_state()
            self.current_image = self.original_image.copy()
            self.zoom_factor = 1.0
            self.clear_watermark_selection()
            self.update_display()
            self.status_bar.config(text="已重置")

    def update_display(self):
        if self.current_image is None:
            return

        width, height = self.current_image.size
        display_width = int(width * self.zoom_factor)
        display_height = int(height * self.zoom_factor)

        resized = self.current_image.resize((display_width, display_height), Image.Resampling.LANCZOS)
        self.display_image = ImageTk.PhotoImage(resized)

        self.canvas.config(scrollregion=(0, 0, display_width, display_height))
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.display_image)

        if self.watermark_start and self.watermark_end:
            self.draw_watermark_rect()

    def update_info(self):
        if self.current_image:
            width, height = self.current_image.size
            mode = self.current_image.mode
            file_name = os.path.basename(self.file_path) if self.file_path else "未命名"
            self.info_label.config(
                text=f"文件: {file_name}\n尺寸: {width} x {height}\n模式: {mode}\n缩放: {int(self.zoom_factor * 100)}%")

    def zoom(self, factor):
        if self.current_image:
            self.zoom_factor *= factor
            self.zoom_factor = max(0.1, min(5.0, self.zoom_factor))
            self.update_display()
            self.update_info()

    def fit_to_window(self):
        if self.current_image is None:
            return

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        img_width, img_height = self.current_image.size

        if img_width > 0 and img_height > 0:
            scale_w = (canvas_width - 20) / img_width
            scale_h = (canvas_height - 20) / img_height
            self.zoom_factor = min(scale_w, scale_h, 1.0)
            self.update_display()
            self.update_info()

    def get_canvas_coords(self, event):
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        return x, y

    def canvas_to_image_coords(self, x, y):
        img_x = int(x / self.zoom_factor)
        img_y = int(y / self.zoom_factor)
        return img_x, img_y

    def on_mouse_down(self, event):
        if self.current_image is None:
            return

        x, y = self.get_canvas_coords(event)

        if self.watermark_mode:
            self.watermark_selecting = True
            self.watermark_start = (x, y)
            self.watermark_end = None
            self.detection_mask = None
            if self.watermark_rect:
                self.canvas.delete(self.watermark_rect)
                self.watermark_rect = None
        else:
            self.drawing = True
            self.last_x, self.last_y = x, y

            if self.draw_mode == "取色器":
                self.pick_color(x, y)

    def on_mouse_move(self, event):
        if self.current_image is None:
            return

        x, y = self.get_canvas_coords(event)

        if self.watermark_mode and self.watermark_selecting:
            self.watermark_end = (x, y)
            self.draw_watermark_rect()
        elif self.drawing and self.draw_mode in ["铅笔", "橡皮"]:
            self.draw_line(self.last_x, self.last_y, x, y)
            self.last_x, self.last_y = x, y

    def on_mouse_up(self, event):
        if self.watermark_mode and self.watermark_selecting:
            self.watermark_selecting = False
            if self.watermark_start and self.watermark_end:
                x1, y1 = self.watermark_start
                x2, y2 = self.watermark_end
                self.watermark_start = (min(x1, x2), min(y1, y2))
                self.watermark_end = (max(x1, x2), max(y1, y2))
                width = abs(x2 - x1)
                height = abs(y2 - y1)
                self.status_bar.config(text=f"已框选区域 ({width:.0f}x{height:.0f})，点击\"智能分析\"")
        else:
            self.drawing = False
            self.last_x = None
            self.last_y = None

    def on_mouse_hover(self, event):
        if self.current_image is None:
            return

        x, y = self.get_canvas_coords(event)
        img_x, img_y = self.canvas_to_image_coords(x, y)
        width, height = self.current_image.size

        if 0 <= img_x < width and 0 <= img_y < height:
            if not self.watermark_mode and not self.drawing:
                self.status_bar.config(text=f"位置: ({img_x}, {img_y})")

    def draw_line(self, x1, y1, x2, y2):
        img_x1, img_y1 = self.canvas_to_image_coords(x1, y1)
        img_x2, img_y2 = self.canvas_to_image_coords(x2, y2)

        width, height = self.current_image.size
        if not (0 <= img_x1 < width and 0 <= img_y1 < height):
            return

        draw = ImageDraw.Draw(self.current_image)

        if self.draw_mode == "铅笔":
            color = self.current_color + (255,)
            draw.line([(img_x1, img_y1), (img_x2, img_y2)], fill=color, width=self.size_scale.get())
            r = self.size_scale.get() // 2
            draw.ellipse([img_x1 - r, img_y1 - r, img_x1 + r, img_y1 + r], fill=color)
            draw.ellipse([img_x2 - r, img_y2 - r, img_x2 + r, img_y2 + r], fill=color)
        elif self.draw_mode == "橡皮":
            draw.line([(img_x1, img_y1), (img_x2, img_y2)], fill=(0, 0, 0, 0), width=self.size_scale.get() * 2)

        self.update_display()

    def pick_color(self, x, y):
        img_x, img_y = self.canvas_to_image_coords(x, y)
        width, height = self.current_image.size

        if 0 <= img_x < width and 0 <= img_y < height:
            pixel = self.current_image.getpixel((img_x, img_y))
            if len(pixel) == 4:
                self.current_color = pixel[:3]
            else:
                self.current_color = pixel
            self.update_color_preview()
            self.update_rgb_entries()
            self.set_draw_mode("铅笔")

    def start_watermark_selection(self):
        if self.current_image is None:
            messagebox.showwarning("警告", "请先打开图片")
            return

        self.watermark_mode = True
        self.watermark_selecting = False
        self.watermark_start = None
        self.watermark_end = None
        self.detection_mask = None

        self.pencil_btn.config(bg='#4b4b4b')
        self.eraser_btn.config(bg='#4b4b4b')
        self.picker_btn.config(bg='#4b4b4b')
        self.wm_select_btn.config(bg='#5b5b5b', fg='#ffeb3b')

        self.status_bar.config(text="框选水印大致区域")

    def draw_watermark_rect(self):
        if self.watermark_start is None or self.watermark_end is None:
            return

        if self.watermark_rect:
            self.canvas.delete(self.watermark_rect)

        x1, y1 = self.watermark_start
        x2, y2 = self.watermark_end

        self.watermark_rect = self.canvas.create_rectangle(
            x1, y1, x2, y2, outline='#ff6b6b', width=3, dash=(6, 4)
        )

    def smart_detect_watermark(self):
        """智能分析水印边界"""
        if self.current_image is None or self.watermark_start is None or self.watermark_end is None:
            messagebox.showwarning("警告", "请先框选水印区域")
            return

        try:
            self.status_bar.config(text="正在智能分析水印...")
            self.root.update()

            # 获取框选区域
            cx1, cy1 = self.watermark_start
            cx2, cy2 = self.watermark_end

            ix1, iy1 = self.canvas_to_image_coords(cx1, cy1)
            ix2, iy2 = self.canvas_to_image_coords(cx2, cy2)

            img_x1 = max(0, min(ix1, ix2))
            img_y1 = max(0, min(iy1, iy2))
            img_x2 = min(self.current_image.width, max(ix1, ix2))
            img_y2 = min(self.current_image.height, max(iy1, iy2))

            if img_x2 <= img_x1 or img_y2 <= img_y1:
                messagebox.showwarning("警告", "选择区域无效")
                return

            self.mask_coords = (int(img_x1), int(img_y1), int(img_x2), int(img_y2))

            # 裁剪区域分析
            roi = self.current_image.crop(self.mask_coords)
            roi_array = np.array(roi).astype(np.uint8)

            # 获取ROI尺寸
            roi_h, roi_w = roi_array.shape[:2]

            # 转换为灰度图
            if len(roi_array.shape) == 3:
                gray = cv2.cvtColor(roi_array, cv2.COLOR_RGBA2GRAY)
            else:
                gray = roi_array

            # 计算统计信息
            mean_val = np.mean(gray)
            std_val = np.std(gray)
            sensitivity = self.sensitivity.get() / 50.0

            # 检测高亮和低暗区域
            high_thresh = min(255, int(mean_val + std_val * sensitivity))
            low_thresh = max(0, int(mean_val - std_val * sensitivity))

            _, high_mask = cv2.threshold(gray, high_thresh, 255, cv2.THRESH_BINARY)
            _, low_mask = cv2.threshold(gray, low_thresh, 255, cv2.THRESH_BINARY_INV)

            # 合并
            combined = cv2.bitwise_or(high_mask, low_mask)

            # 边缘检测
            edges = cv2.Canny(gray, 50, 150)
            edges = cv2.dilate(edges, None, iterations=1)

            # 确保维度匹配
            if combined.shape != edges.shape:
                edges = cv2.resize(edges, (combined.shape[1], combined.shape[0]))

            combined = cv2.bitwise_or(combined, edges)

            # 形态学操作
            kernel = np.ones((3, 3), np.uint8)
            combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel, iterations=2)
            combined = cv2.morphologyEx(combined, cv2.MORPH_OPEN, kernel, iterations=1)

            self.detection_mask = combined

            # 统计
            mask_pixels = np.sum(combined > 0)
            total_pixels = combined.size
            ratio = (mask_pixels / total_pixels) * 100 if total_pixels > 0 else 0

            self.status_bar.config(text=f"分析完成: 检测到 {ratio:.1f}% 区域可能是水印")

        except Exception as e:
            messagebox.showerror("错误", f"分析失败: {str(e)}")
            import traceback
            traceback.print_exc()
            self.status_bar.config(text="分析失败")

    def preview_detection(self):
        """预览检测到的水印区域"""
        if self.detection_mask is None or self.current_image is None or self.mask_coords is None:
            messagebox.showwarning("警告", "请先进行智能分析")
            return

        try:
            preview = self.current_image.copy()
            preview_array = np.array(preview)

            img_x1, img_y1, img_x2, img_y2 = self.mask_coords

            # 确保遮罩尺寸匹配
            roi_h = img_y2 - img_y1
            roi_w = img_x2 - img_x1

            mask = self.detection_mask
            if mask.shape != (roi_h, roi_w):
                mask = cv2.resize(mask, (roi_w, roi_h))

            # 红色高亮
            roi = preview_array[img_y1:img_y2, img_x1:img_x2].copy()

            # 创建红色叠加
            red_layer = np.zeros_like(roi[:, :, :3])
            red_layer[:, :, 0] = 255  # R通道

            # 混合
            alpha = 0.5
            for c in range(3):
                roi[:, :, c] = (roi[:, :, c] * (1 - alpha) + red_layer[:, :, c] * alpha * (mask / 255)).astype(np.uint8)

            preview_array[img_y1:img_y2, img_x1:img_x2] = roi

            preview_img = Image.fromarray(preview_array)
            self.current_image = preview_img
            self.update_display()

            self.status_bar.config(text="红色区域为检测到的水印，不满意可调整敏感度重新分析")

        except Exception as e:
            messagebox.showerror("错误", f"预览失败: {str(e)}")
            import traceback
            traceback.print_exc()

    def remove_watermark_deep(self):
        """深度去除水印 - 多次迭代修复"""
        if self.current_image is None:
            messagebox.showwarning("警告", "未加载图片")
            return

        if self.detection_mask is None or self.mask_coords is None:
            messagebox.showwarning("警告", "请先进行智能分析")
            return

        try:
            self.save_state()

            img_x1, img_y1, img_x2, img_y2 = self.mask_coords
            roi_w = img_x2 - img_x1
            roi_h = img_y2 - img_y1

            # 获取参数
            iterations = self.iterations.get()
            radius = self.repair_radius.get()
            feather = self.feather_radius.get()

            self.status_bar.config(text=f"正在深度去除水印 (迭代 {iterations} 次)...")
            self.root.update()

            # 获取原图
            img_array = np.array(self.current_image).astype(np.uint8)

            # 确保遮罩尺寸正确
            mask = self.detection_mask.copy()
            if mask.shape != (roi_h, roi_w):
                mask = cv2.resize(mask, (roi_w, roi_h))

            # 羽化边缘
            if feather > 0:
                mask = cv2.GaussianBlur(mask, (feather * 2 + 1, feather * 2 + 1), 0)

            mask = mask.astype(np.uint8)

            # 提取ROI
            roi = img_array[img_y1:img_y2, img_x1:img_x2].copy()

            # 多次迭代修复
            for i in range(iterations):
                self.status_bar.config(text=f"正在修复... 第 {i + 1}/{iterations} 次迭代")
                self.root.update()

                # 分离通道
                if len(roi.shape) == 3 and roi.shape[2] == 4:
                    roi_rgb = roi[:, :, :3]
                    roi_alpha = roi[:, :, 3]
                else:
                    roi_rgb = roi
                    roi_alpha = None

                # 扩展遮罩确保完全覆盖
                kernel = np.ones((5, 5), np.uint8)
                repair_mask = cv2.dilate(mask, kernel, iterations=1)

                # 使用NS算法（比Telea更平滑）
                repaired_rgb = cv2.inpaint(roi_rgb, repair_mask, radius, cv2.INPAINT_NS)

                # 颜色一致性优化：与周围像素混合
                if i < iterations - 1:  # 最后一次不混合，保持清晰
                    # 轻微模糊减少噪点
                    repaired_rgb = cv2.medianBlur(repaired_rgb, 3)

                # 更新ROI用于下一次迭代
                if roi_alpha is not None:
                    roi = np.dstack([repaired_rgb, roi_alpha])
                else:
                    roi = repaired_rgb

            # 最终混合（根据遮罩强度）
            mask_float = mask.astype(np.float32) / 255.0
            mask_3ch = np.stack([mask_float] * 3, axis=-1)

            # 获取原始ROI
            original_roi = img_array[img_y1:img_y2, img_x1:img_x2].copy()
            if len(original_roi.shape) == 3 and original_roi.shape[2] == 4:
                original_rgb = original_roi[:, :, :3]
                original_alpha = original_roi[:, :, 3]
            else:
                original_rgb = original_roi
                original_alpha = None

            # 混合：遮罩区域用修复结果，其他区域保持原样
            final_rgb = (original_rgb * (1 - mask_3ch) + repaired_rgb * mask_3ch).astype(np.uint8)

            # 处理Alpha通道
            if original_alpha is not None:
                final_alpha = original_alpha.copy()
                # 水印区域设为不透明
                final_alpha[mask > 128] = 255
                final_roi = np.dstack([final_rgb, final_alpha])
            else:
                final_roi = final_rgb

            # 应用回主图
            img_array[img_y1:img_y2, img_x1:img_x2] = final_roi

            self.current_image = Image.fromarray(img_array)

            # 清除状态
            self.watermark_selecting = False
            self.watermark_start = None
            self.watermark_end = None
            self.detection_mask = None
            self.mask_coords = None
            if self.watermark_rect:
                self.canvas.delete(self.watermark_rect)
                self.watermark_rect = None

            self.update_display()
            self.status_bar.config(text=f"深度去除完成！迭代 {iterations} 次，如仍有残留请使用\"检测残留并补充修复\"")

        except Exception as e:
            messagebox.showerror("错误", f"去除失败: {str(e)}")
            import traceback
            traceback.print_exc()
            self.status_bar.config(text="去除失败")

    def check_and_fix_residue(self):
        """检测残留水印并补充修复"""
        if self.current_image is None:
            messagebox.showwarning("警告", "未加载图片")
            return

        # 需要重新框选区域进行检测
        if self.mask_coords is None:
            messagebox.showinfo("提示", "请重新框选可能还有残留的区域，然后点击此按钮")
            self.start_watermark_selection()
            return

        try:
            self.status_bar.config(text="正在检测残留...")
            self.root.update()

            img_x1, img_y1, img_x2, img_y2 = self.mask_coords

            # 获取当前区域的图像
            roi = self.current_image.crop((img_x1, img_y1, img_x2, img_y2))
            roi_array = np.array(roi).astype(np.uint8)

            # 转换为灰度
            if len(roi_array.shape) == 3:
                gray = cv2.cvtColor(roi_array, cv2.COLOR_RGBA2GRAY)
            else:
                gray = roi_array

            # 检测残留：寻找与周围差异大的像素
            # 使用拉普拉斯算子检测边缘/纹理异常
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            laplacian = np.abs(laplacian)

            # 归一化
            laplacian = (laplacian / laplacian.max() * 255).astype(np.uint8)

            # 阈值检测高纹理区域（可能是残留水印）
            _, residue_mask = cv2.threshold(laplacian, 50, 255, cv2.THRESH_BINARY)

            # 形态学操作连接区域
            kernel = np.ones((3, 3), np.uint8)
            residue_mask = cv2.morphologyEx(residue_mask, cv2.MORPH_CLOSE, kernel, iterations=2)

            # 过滤小区域（噪点）
            contours, _ = cv2.findContours(residue_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            min_area = 50  # 最小面积阈值
            filtered_mask = np.zeros_like(residue_mask)

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area > min_area:
                    cv2.drawContours(filtered_mask, [cnt], -1, 255, -1)

            # 检查是否有残留
            residue_pixels = np.sum(filtered_mask > 0)
            total_pixels = filtered_mask.size
            residue_ratio = (residue_pixels / total_pixels) * 100

            if residue_ratio < 1.0:
                self.status_bar.config(text="未检测到明显残留，水印已去除干净！")
                messagebox.showinfo("完成", "未检测到明显残留，水印已去除干净！")
                return

            # 使用残留遮罩进行补充修复
            self.status_bar.config(text=f"检测到 {residue_ratio:.1f}% 残留，正在补充修复...")
            self.root.update()

            # 保存状态
            self.save_state()

            # 更新遮罩为残留遮罩
            self.detection_mask = filtered_mask

            # 调用深度去除（使用更激进的参数）
            old_iterations = self.iterations.get()
            old_radius = self.repair_radius.get()

            self.iterations.set(3)  # 增加迭代
            self.repair_radius.set(7)  # 增加半径

            self.remove_watermark_deep()

            # 恢复参数
            self.iterations.set(old_iterations)
            self.repair_radius.set(old_radius)

            self.status_bar.config(text="补充修复完成！")

        except Exception as e:
            messagebox.showerror("错误", f"检测失败: {str(e)}")
            import traceback
            traceback.print_exc()

    def clear_watermark_selection(self):
        self.watermark_mode = False
        self.watermark_selecting = False
        self.watermark_start = None
        self.watermark_end = None
        self.detection_mask = None
        self.mask_coords = None
        if self.watermark_rect:
            self.canvas.delete(self.watermark_rect)
            self.watermark_rect = None
        self.wm_select_btn.config(bg='#4b4b4b', fg='white')
        self.set_draw_mode("铅笔")
        self.status_bar.config(text="已清除选择")

    def apply_resolution(self):
        if self.current_image is None:
            messagebox.showwarning("警告", "未加载图片")
            return

        self.save_state()
        res_str = self.res_var.get()
        if res_str == "原始尺寸":
            self.current_image = self.original_image.copy()
        else:
            try:
                size = int(res_str.split('x')[0])
                self.current_image = self.original_image.resize((size, size), Image.Resampling.LANCZOS)
            except:
                messagebox.showerror("错误", "分辨率格式错误")
                return

        self.zoom_factor = 1.0
        self.clear_watermark_selection()
        self.update_display()
        self.update_info()
        self.status_bar.config(text=f"分辨率已更改为 {res_str}")


def create_launcher():
    bat_content = '''@echo off
chcp 65001 >nul
title 图片编辑器启动器

echo ========================================
echo      图片编辑器启动器
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到Python，请安装Python 3.8+
    pause
    exit
)

echo [OK] Python已检测到。
echo 检查依赖...

python -c "import PIL" 2>nul || (echo 安装Pillow... && pip install Pillow -i https://pypi.tuna.tsinghua.edu.cn/simple -q)
python -c "import numpy" 2>nul || (echo 安装NumPy... && pip install numpy -i https://pypi.tuna.tsinghua.edu.cn/simple -q)
python -c "import cv2" 2>nul || (echo 安装OpenCV... && pip install opencv-python -i https://pypi.tuna.tsinghua.edu.cn/simple -q)

echo [OK] 依赖就绪，启动中...
python images_editor.py
pause
'''

    with open("start.bat", "w", encoding="utf-8") as f:
        f.write(bat_content)


def main():
    if not os.path.exists("start.bat"):
        create_launcher()

    root = tk.Tk()
    app = ImagesEditor(root)
    root.mainloop()


if __name__ == "__main__":
    main()