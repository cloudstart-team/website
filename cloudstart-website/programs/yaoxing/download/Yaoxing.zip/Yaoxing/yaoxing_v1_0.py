#!/usr/bin/env python3
# yaoxing_v1_0.py  —— 离线收益版（最多24h）+ 无反作弊 + v1.0
import pygame, sys, json, os, time, math
from pygame import freetype
import gmpy2

# ---------------- 常数 ----------------
SAVE_FILE = "save.json"
WIDTH, HEIGHT = 960, 540
FPS = 60
FLOAT_MAX = 1.7976931348623157e+308
MAX_OFFLINE_SECONDS = 24 * 3600          # 24h 上限
# 字体：同级目录优先
FONT_PATH = os.path.join(os.path.dirname(__file__), 'simhei.ttf')
if not os.path.exists(FONT_PATH):
    FONT_PATH = None
# -------------------------------------

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("耀星 v1.0 离线收益版")
clock = pygame.time.Clock()

if FONT_PATH:
    font20 = freetype.Font(FONT_PATH, 20)
    font30 = freetype.Font(FONT_PATH, 30)
else:
    font20 = freetype.SysFont("simhei", 20)
    font30 = freetype.SysFont("simhei", 30)

# ---------- 存档 ----------
def new_save():
    return dict(stars=1.0, world_stars=0, control=0.0, global_mult=1.0, shop_price=1,
                total_clicks=0, heat_death_times=0, infinity_times=0,
                god_fragment=0, shop_times=0, universe_id=1, universe_count=1,
                achieved=[], last_save_time=time.time())

def load():
    if not os.path.exists(SAVE_FILE):
        return new_save()
    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data

def save(data):
    data["last_save_time"] = time.time()
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# ---------- 离线收益 ----------
def calc_offline_bonus(data):
    now = time.time()
    last = data.get("last_save_time", now)
    delta = min(int(now - last), MAX_OFFLINE_SECONDS)
    if delta <= 0:
        return 0
    # 离线只按“当前倍率”线性累积，不增加速率
    rate = data["global_mult"]
    bonus = rate * delta * 0.2        # 20% 效率，可调
    return bonus

# ---------- Game ----------
class Game:
    def __init__(self):
        self.d = load()
        # 上线领离线收益
        offline_bonus = calc_offline_bonus(self.d)
        if offline_bonus > 0:
            self.d["stars"] += offline_bonus
            print(f"[离线] 获得 {offline_bonus:.0f} 耀星")
        self.stars = gmpy2.mpfr(self.d["stars"])
        self.load_to_mem()
        self.last_inflate = 0
        self.inflate_speed = 1000

    def load_to_mem(self):
        self.total_clicks = self.d["total_clicks"]
        self.heat_death_times = self.d["heat_death_times"]
        self.infinity_times = self.d["infinity_times"]
        self.shop_times = self.d["shop_times"]
        self.god_fragment = self.d["god_fragment"]
        self.universe_id = self.d["universe_id"]
        self.universe_count = self.d["universe_count"]

    def click(self):
        self.stars += 1 * self.d["global_mult"]
        self.total_clicks += 1
        self.d["total_clicks"] = self.total_clicks

    def inflate(self, dt):
        self.last_inflate += dt
        if self.last_inflate >= self.inflate_speed:
            self.last_inflate = 0
            self.stars *= 1.05 * self.d["global_mult"]

    def try_heat_death(self):
        if float(self.stars) >= FLOAT_MAX:
            self.stars = gmpy2.mpfr(1)
            self.d["world_stars"] += 1
            self.heat_death_times += 1
            self.d["heat_death_times"] = self.heat_death_times
            return True
        return False

    def try_infinity(self):
        if self.d["world_stars"] >= FLOAT_MAX:
            self.d["world_stars"] = 0
            self.infinity_times += 1
            self.d["infinity_times"] = self.infinity_times
            self.d["control"] += 0.01
            return True
        return False

    def buy_upgrade(self):
        if self.d["world_stars"] >= self.d["shop_price"]:
            self.d["world_stars"] -= self.d["shop_price"]
            self.d["global_mult"] *= 1.5
            self.shop_times += 1
            self.d["shop_times"] = self.shop_times
            self.d["shop_price"] += 1
            return True
        return False

    def new_universe(self):
        self.d["universe_id"] += 1
        self.d["universe_count"] = max(self.d["universe_count"], self.d["universe_id"])
        self.d["stars"] = 1.0
        self.d["world_stars"] = 0
        self.d["control"] = 0.0
        self.d["global_mult"] = 1.0
        self.d["shop_price"] = 1
        self.stars = gmpy2.mpfr(1)
        self.load_to_mem()

    def check_achievements(self):
        for aid, (desc, cond) in ACH_LIST.items():
            if aid not in self.d["achieved"] and cond(self):
                self.d["achieved"].append(aid)
                print(f"[成就] {desc}")

    def save_all(self):
        self.d["stars"] = float(self.stars) if self.stars < FLOAT_MAX else FLOAT_MAX
        save(self.d)

# ---------------- 成就表 ----------------
ACH_LIST = {
    "first_click": ("初窥耀星", lambda g: g.total_clicks >= 1),
    "million":     ("百万富翁", lambda g: float(g.stars) >= 1e6),
    "e50":         ("星河级", lambda g: float(g.stars) >= 1e50),
    "heat_death":  ("热寂行者", lambda g: g.heat_death_times >= 1),
    "infinity":    ("无穷超越", lambda g: g.infinity_times >= 1),
    "god_once":    ("第一次成神", lambda g: g.god_fragment >= 1),
    "shop_10":     ("剁手党", lambda g: g.shop_times >= 10),
    "click_1k":    ("千次之手", lambda g: g.total_clicks >= 1000),
    "speedy":      ("光速膨胀", lambda g: g.d["global_mult"] >= 1e6),
    "multiverse":  ("多宇宙开启", lambda g: g.universe_count >= 2),
}

# ---------------- UI ----------------
class UI:
    def __init__(self, game):
        self.g = game
        self.btn_click = pygame.Rect(30, 120, 200, 50)
        self.btn_shop = pygame.Rect(30, 180, 200, 50)
        self.btn_newu = pygame.Rect(30, 240, 200, 50)
        self.btn_ach = pygame.Rect(30, 300, 200, 50)
        # 成就面板
        self.ach_panel = pygame.Rect(WIDTH - 250, 100, 230, 300)
        self.show_ach = False
        # 确认弹窗
        self.confirm_rect = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 - 80, 300, 160)
        self.confirm_text = ""
        self.on_confirm = None
        self.show_confirm = False

    def draw(self, surf):
        surf.fill((20, 20, 30))
        font30.render_to(surf, (30, 20), "耀星 v1.0 离线收益版", (255, 200, 50))
        font20.render_to(surf, (30, 70), f"耀星: {float(self.g.stars):.2e}", (255, 255, 255))
        font20.render_to(surf, (300, 70), f"世界之星: {self.g.d['world_stars']}", (255, 220, 100))
        font20.render_to(surf, (550, 70), f"掌控: {self.g.d['control']:.2f}%", (100, 255, 100))
        font20.render_to(surf, (30, 360), f"神性碎片: {self.g.god_fragment}", (255, 100, 255))

        for r, txt in [(self.btn_click, "点击 +1"),
                       (self.btn_shop, f"买增益({self.g.d['shop_price']})"),
                       (self.btn_newu, "新宇宙+"),
                       (self.btn_ach, f"成就({len(self.g.d['achieved'])})")]:
            pygame.draw.rect(surf, (0, 150, 255), r, border_radius=6)
            font20.render_to(surf, (r.x + 20, r.centery - 10), txt, (255, 255, 255))

        # 成就面板
        pygame.draw.rect(surf, (40, 40, 50), self.ach_panel, border_radius=8)
        if self.show_ach:
            font20.render_to(surf, (self.ach_panel.x + 10, self.ach_panel.y + 10),
                             "成就列表", (255, 200, 50))
            for i, aid in enumerate(self.g.d["achieved"]):
                font20.render_to(surf, (self.ach_panel.x + 10, self.ach_panel.y + 40 + i * 25),
                                 f"- {ACH_LIST[aid][0]}", (200, 200, 200))
        else:
            font20.render_to(surf, (self.ach_panel.x + 10, self.ach_panel.y + 10),
                             f"成就({len(self.g.d['achieved'])})", (200, 200, 200))

        # 确认弹窗
        if self.show_confirm:
            cover = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            cover.fill((0, 0, 0, 150))
            surf.blit(cover, (0, 0))
            pygame.draw.rect(surf, (40, 40, 50), self.confirm_rect, border_radius=10)
            pygame.draw.rect(surf, (200, 200, 200), self.confirm_rect, 2, border_radius=10)
            font20.render_to(surf, (self.confirm_rect.x + 20, self.confirm_rect.y + 20),
                             self.confirm_text, (255, 255, 255))
            btn_ok   = pygame.Rect(self.confirm_rect.x + 30, self.confirm_rect.y + 100, 80, 35)
            btn_cancel = pygame.Rect(self.confirm_rect.x + 190, self.confirm_rect.y + 100, 80, 35)
            pygame.draw.rect(surf, (0, 150, 0), btn_ok, border_radius=5)
            pygame.draw.rect(surf, (150, 0, 0), btn_cancel, border_radius=5)
            font20.render_to(surf, (btn_ok.x + 15, btn_ok.y + 5), "确认", (255, 255, 255))
            font20.render_to(surf, (btn_cancel.x + 10, btn_cancel.y + 5), "取消", (255, 255, 255))

        if self.g.d["control"] >= 100 and not self.g.egged:
            font30.render_to(surf, (WIDTH // 2 - 200, HEIGHT // 2), "玩家好像注意到我们了......", (255, 50, 50))
            self.g.egged = True
            self.g.god_fragment += 1
            print("[剧情] 你已成为世界之神！")

    def check_click(self, pos):
        # 弹窗模式下只处理弹窗按钮
        if self.show_confirm:
            btn_ok   = pygame.Rect(self.confirm_rect.x + 30, self.confirm_rect.y + 100, 80, 35)
            btn_cancel = pygame.Rect(self.confirm_rect.x + 190, self.confirm_rect.y + 100, 80, 35)
            if btn_ok.collidepoint(pos):
                self.show_confirm = False
                if self.on_confirm:
                    self.on_confirm()
            elif btn_cancel.collidepoint(pos):
                self.show_confirm = False
            return

        # 主按钮
        if self.btn_click.collidepoint(pos):
            self.g.click()
        if self.btn_shop.collidepoint(pos):
            self.ask_shop()
        if self.btn_newu.collidepoint(pos):
            self.ask_newu()
        if self.btn_ach.collidepoint(pos):
            self.show_ach = not self.show_ach

    # ------------ 询问函数 ------------
    def ask_shop(self):
        self.confirm_text = f"确定花费 {self.g.d['shop_price']} 世界之星购买增益？"
        self.on_confirm   = self.g.buy_upgrade
        self.show_confirm = True

    def ask_newu(self):
        self.confirm_text = "确定重置进度并进入新宇宙？"
        self.on_confirm   = self.g.new_universe
        self.show_confirm = True

# ---------------- main ----------------
def main():
    game = Game()
    ui = UI(game)
    # ===== 启动阻塞：按任意键开始 =====
    waiting = True
    while waiting:
        screen.fill((20, 20, 30))
        font30.render_to(screen, (WIDTH//2 - 120, HEIGHT//2), '按任意键开始', (255,255,255))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False
    # ===================================
    running = True
    while running:
        dt = clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                ui.check_click(event.pos)

        game.inflate(dt)
        if game.try_heat_death():
            print("[事件] 热寂！")
        if game.try_infinity():
            print("[事件] 无穷！")
        game.check_achievements()

        ui.draw(screen)
        pygame.display.flip()
        game.save_all()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()