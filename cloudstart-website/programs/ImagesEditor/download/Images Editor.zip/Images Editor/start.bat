@echo off
chcp 65001 >nul
title 图片编辑器启动器

echo ========================================
echo      图片编辑器启动器
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到Python，请安装Python 3.8+
    pause
    exit
)

echo [OK] Python已检测到。
echo 检查依赖...

python -c "import PIL" 2>nul || (echo 安装Pillow... && pip install Pillow -i https://pypi.tuna.tsinghua.edu.cn/simple -q)
python -c "import numpy" 2>nul || (echo 安装NumPy... && pip install numpy -i https://pypi.tuna.tsinghua.edu.cn/simple -q)
python -c "import cv2" 2>nul || (echo 安装OpenCV... && pip install opencv-python -i https://pypi.tuna.tsinghua.edu.cn/simple -q)

echo [OK] 依赖就绪，启动中...
python images_editor.py
pause